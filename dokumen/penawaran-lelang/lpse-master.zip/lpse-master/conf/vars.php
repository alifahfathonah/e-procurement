<?php 
	$base_url = 'http://'.$_SERVER['SERVER_NAME'];
	$path     = 'http://'.$_SERVER['PHP_SELF'];
	$q        = 'http://'.$_SERVER['QUERY_STRING'];
?>