<!DOCTYPE html>
<html>
<head>
<title>REKENING</title>
<meta charset="utf-8">
<link type="text/css" rel="stylesheet" href="css/kondisi.css">
</head>
<body>
<div class=kondisi>
<?php
	$kon=mysql_connect("localhost","root","Zaifulati123") or die("Koneksi Gagal");
		mysql_select_db("tabungan");
	if(isset($_POST[submit])){ 
		$Rekening=$_POST[rekening];
		$Tgl=$_POST[tgl];
		$Nominal=$_POST['nominal'];
		$Kode=$_POST[kode];
		
		$ambil=mysql_query("SELECT * FROM nasabah WHERE id_rekening='$Rekening'");
		$hasil=mysql_fetch_array($ambil);
		echo"<form method=post action=rekening.php>
	     <table width=600px cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:#ccffff;'>
		 <tr style='background-color:#ccffaa;'><td colspan=3 style='text-align:left;'>TRANSAKSI REKENING</td><td colspan=4 style='text-align:right;'>Nasabah : $hasil[nama_nasabah]</td></tr>
		 <tr><td colspan=3 width='500px'>No. Rekening</td><td></td><td colspan=3><input style='width:160px;' type=text name=rekening size=15 value='$hasil[id_rekening]' readonly></td></tr>
		 <tr><td colspan=3>Tanggal</td><td></td><td colspan=3><input type=text style='width:80px;' name=tgl size=40 value='$Tgl'></td></tr>
		 <tr><td colspan=3>Nominal</td><td width=30px>Rp.</td><td colspan=3><input type=text name=nominal style='width:120px;' value='$Nominal'></td></tr>
		 <tr><td colspan=3>Kode Transaksi</td><td></td><td colspan=3><SELECT style='width:120px;' name=kode>
								   <option value='002'>Setor Tunai</option>
								   <option value='003'>Tarik Tunai</option>
								   <option value='004'>Transfer</option>
								   <option value='005'>Bayar Listrik</option>
								   <option value='006'>Bayar Telepon</option>
								   <option value='007'>Beli Pulsa</option>
		                           </SELECT></td></tr>
		 <tr><td colspan=7 style='text-align:center;'><input type=submit name=submit value=SUBMIT></td></tr>
		 </table></form>";
		 
			if($Kode=='002'){
				$pilih=mysql_query("SELECT SUM(debit) as DEBIT, SUM(kredit) as KREDIT 
				         FROM rekening WHERE no_rekening='$Rekening'");
						 $data=mysql_fetch_array($pilih);
						 $kredit=$data[KREDIT];
					     $debit=$data[DEBIT];
						 $saldo=($kredit+$Nominal)-$debit;
   		                 $input=mysql_query("INSERT INTO rekening(no_rekening,id_nasabah,tgl,debit,kredit,saldo,kode)values
			                 ('$Rekening','','$Tgl',0,'$Nominal','$saldo','$Kode')"); 
			}elseif($Kode=='003'){
				$pilih=mysql_query("SELECT SUM(debit) as DEBIT, SUM(kredit) as KREDIT 
				         FROM rekening WHERE no_rekening='$Rekening'");
						 $data=mysql_fetch_array($pilih);
						 $kredit=$data[KREDIT];
					     $debit=$data[DEBIT];
						 $saldo=$kredit-($debit+$Nominal);
   		                 $input=mysql_query("INSERT INTO rekening(no_rekening,id_nasabah,tgl,debit,kredit,saldo,kode)values
			                 ('$Rekening','','$Tgl','$Nominal',0,'$saldo','$Kode')"); 
			}elseif($Kode=='004'){
				$pilih=mysql_query("SELECT SUM(debit) as DEBIT, SUM(kredit) as KREDIT 
				         FROM rekening WHERE no_rekening='$Rekening'");
						 $data=mysql_fetch_array($pilih);
						 $kredit=$data[KREDIT];
					     $debit=$data[DEBIT];
						 $saldo=$kredit-($debit+$Nominal);
   		                 $input=mysql_query("INSERT INTO rekening(no_rekening,id_nasabah,tgl,debit,kredit,saldo,kode)values
			                 ('$Rekening','','$Tgl','$Nominal',0,'$saldo','$Kode')"); 
			}elseif($Kode=='005'){
				$pilih=mysql_query("SELECT SUM(debit) as DEBIT, SUM(kredit) as KREDIT 
				         FROM rekening WHERE no_rekening='$Rekening'");
						 $data=mysql_fetch_array($pilih);
						 $kredit=$data[KREDIT];
					     $debit=$data[DEBIT];
						 $saldo=$kredit-($debit+$Nominal);
   		                 $input=mysql_query("INSERT INTO rekening(no_rekening,id_nasabah,tgl,debit,kredit,saldo,kode)values
			                 ('$Rekening','','$Tgl','$Nominal',0,'$saldo','$Kode')"); 
			}elseif($Kode=='006'){
				$pilih=mysql_query("SELECT SUM(debit) as DEBIT, SUM(kredit) as KREDIT 
				         FROM rekening WHERE no_rekening='$Rekening'");
						 $data=mysql_fetch_array($pilih);
						 $kredit=$data[KREDIT];
					     $debit=$data[DEBIT];
						 $saldo=$kredit-($debit+$Nominal);
   		                 $input=mysql_query("INSERT INTO rekening(no_rekening,id_nasabah,tgl,debit,kredit,saldo,kode)values
			                 ('$Rekening','','$Tgl','$Nominal',0,'$saldo','$Kode')"); 
			}elseif($Kode=='007'){
				$pilih=mysql_query("SELECT SUM(debit) as DEBIT, SUM(kredit) as KREDIT 
				         FROM rekening WHERE no_rekening='$Rekening'");
						 $data=mysql_fetch_array($pilih);
						 $kredit=$data[KREDIT];
					     $debit=$data[DEBIT];
						 $saldo=$kredit-($debit+$Nominal);
   		                 $input=mysql_query("INSERT INTO rekening(no_rekening,id_nasabah,tgl,debit,kredit,saldo,kode)values
			                 ('$Rekening','','$Tgl','$Nominal',0,'$saldo','$Kode')"); 
			}
		
		 $pilih1=mysql_query("SELECT * FROM rekening WHERE no_rekening='$Rekening'"); $no=1;
		 
		 echo"<table width=500px border=1 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:magenta;'>
		 <tr style='background-color:#ccffaa;'><td colspan=7 style='text-align:center;'>DATA TRANSAKSI </td></tr>";
		 echo"<tr style='background-color:#ccffaa;'><td>No</td><td>No. Rekening</td><td>Tanggal</td><td>Debit</td><td>Kredit</td><td>Saldo</td><td>Kode</td></tr>";
		 while($data=mysql_fetch_array($pilih1))
		 {
		 echo"<tr><td>$no.</td><td>$data[no_rekening]</td><td>$data[tgl]</td>
		                       <td style='text-align:right;'>".rupiah($data[debit])."</td><td style='text-align:right;'>".rupiah($data[kredit])."</td>
							   <td style='text-align:right;'>".rupiah($data[saldo])."</td><td>$data[kode]</td>
		 </tr>";
		 $no++;
		 }
	}else{
		$Rekening = $_GET[rek];
		$ambil=mysql_query("SELECT * FROM nasabah WHERE id_rekening='$Rekening'");
		$hasil=mysql_fetch_array($ambil);
	echo"<form method=post action=rekening.php>
	     <table width=600px border=1 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:#ccffff;'>
		 <tr style='background-color:#ccffaa;'><td colspan=3 style='text-align:left;'>TRANSAKSI REKENING</td><td colspan=4 style='text-align:right;'>Nasabah : $hasil[nama_nasabah]</td></tr>
		 <tr><td colspan=3 width='500px'>No. Rekening</td><td ></td><td colspan=3><input style='width:160px;' type=text name=rekening size=15 value='$hasil[id_rekening]' readonly></td></tr>
		 <tr><td colspan=3>Tanggal</td><td></td><td colspan=3><input type=text style='width:80px;' name=tgl size=40 value='$Tgl'></td></tr>
		 <tr><td colspan=3>Nominal</td><td width=30px>Rp.</td><td colspan=3><input type=text name=nominal style='width:120px;' value='$Nominal'></td></tr>
		 <tr><td colspan=3>Kode Transaksi</td><td></td><td colspan=3 ><SELECT style='width:120px;' name=kode>
								   <option value='002'>Setor Tunai</option>
								   <option value='003'>Tarik Tunai</option>
								   <option value='004'>Transfer</option>
								   <option value='005'>Bayar Listrik</option>
								   <option value='006'>Bayar Telepon</option>
								   <option value='007'>Beli Pulsa</option>
		                           </SELECT></td></tr>
		 <tr><td colspan=7 style='text-align:center;'><input type=submit name=submit value=SUBMIT></td></tr>
		 </table></form>";
		 $pilih1=mysql_query("SELECT * FROM rekening WHERE no_rekening='$Rekening'"); $no=1;
		 
		 echo"<table width=500px border=1 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:#ccffff;'>
		 <tr style='background-color:#ccffaa;'><td colspan=7 style='text-align:center;'>DATA TRANSAKSI </td></tr>";
		 echo"<tr style='background-color:#ccffaa;'><td>No</td><td>No. Rekening</td><td>Tanggal</td><td>Debit</td><td>Kredit</td><td>Saldo</td><td>Kode</td></tr>";
		 while($data=mysql_fetch_array($pilih1))
		 {
		 echo"<tr><td>$no.</td><td>$data[no_rekening]</td><td>$data[tgl]</td>
		                       <td style='text-align:right;'>".rupiah($data[debit])."</td><td style='text-align:right;'>".rupiah($data[kredit])."</td>
							   <td style='text-align:right;'>".rupiah($data[saldo])."</td><td>$data[kode]</td>
		 </tr>";
		 $no++;
		}
	}
		 function rupiah($angka){
	
			$hasil_rupiah = number_format($angka,2,',','.');
			return $hasil_rupiah;
     	 }
		 echo"</table>";
?>
</div>
</body>
</html>