<!DOCTYPE html>
<html>
<head>
<title>SALDO</title>
<meta charset="utf-8">
<link type="text/css" rel="stylesheet" href="css/kondisi.css">
</head>
<body>
<div class=kondisi>
<?php
	$kon=mysql_connect("localhost","root","Zaifulati123") or die("Koneksi Gagal");
		mysql_select_db("tabungan");
	if(isset($_POST[submit]) AND $_POST[bunga]=='saldoterendah'){ 
		$Rekening=$_POST[rekening];
		$Bln=$_POST[bln];
		
		$ambil=mysql_query("SELECT * FROM nasabah WHERE id_rekening='$Rekening'");
		$hasil=mysql_fetch_array($ambil);
	echo"<form method=post action=saldo_terendah.php>
	     <table width=700px border=1 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:#ccffff;'>
		 <tr style='background-color:#ccffaa;'><td style='text-align:left;'>TRANSAKSI SALDO TERENDAH</td><td style='text-align:right;'>Nasabah : $hasil[nama_nasabah]</td></tr>
		 <tr><td width='400px'>No. Rekening</td><td width='300px'><input type=text name=rekening value='$hasil[id_rekening]' readonly></td></tr>
		 <tr><td>Bulan</td><td><select name=bln>";
			for($i=1;$i<=12;$i++)
			{ 
				if($i<10){
				echo"<option value=0$i>0$i</option>";
				}else{
					echo"<option value=$i>$i</option>";
				}	
			}
		 echo"</select></td></tr>
		 <tr><td>Hitung Bunga</td><td><select name=bunga>";
			
				echo"<option value=saldoterendah>Saldo Terendah</option>
					 <option value=saldoratarata>Saldo Rata-Rata</option>
					 <option value=saldoharian>Saldo Harian</option>";
				
		 echo"</select></td></tr>
		 <tr><td>Bunga</td><td><select name=model>";
			
				echo"<option value=harian>Harian</option>
					 <option value=bulanan>Bulanan</option>";
				
		 echo"</select></td></tr>
		 <tr><td>Persen Bunga</td><td><select name=persen>";
			    for($k=1;$k<=24;$k++){
				echo"<option value=$k>$k</option>";
				}
		 echo"</select>%</td></tr>
		 <tr><td>Pajak</td><td><select name=pajak>";
			    for($k=1;$k<=15;$k++){
				echo"<option value=$k>$k</option>";
				}
		 echo"</select>%</td></tr>
		 <tr><td colspan=2 style='text-align:center;'><input type=submit name=submit value=SUBMIT></td></tr>
		 </table></form>";
		$pilih1=mysql_query("SELECT MIN(saldo) as terendah,tgl FROM rekening WHERE no_rekening='$Rekening' AND MID(tgl,6,2)='$Bln'"); 
		 
		 $data=mysql_fetch_array($pilih1);
		 echo"<table width=500px border=1 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:#ccffff;'>";
		 echo"<tr style='background-color:#ccffaa;'>";
		 if($Bln=="01"){
			 $Bln="Januari";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln </td><td colspan=3 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="02"){
			 $Bln="Februari";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="03"){
			 $Bln="Maret";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="04"){
			 $Bln="April";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="05"){
			 $Bln="Mei";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="06"){
			 $Bln="Juni";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="07"){
			 $Bln="Juli";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="08"){
			 $Bln="Agustus";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="09"){
			 $Bln="September";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="10"){
			 $Bln="Oktober";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="11"){
			 $Bln="November";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="12"){
			 $Bln="Desember";
		 echo"<td colspan=3>SALDO TERENDAH : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }
		 echo"</tr></table>";
	}elseif(isset($_POST[submit]) AND $_POST[bunga]=='saldoratarata'){
		$Rekening=$_POST[rekening];
		$Bln=$_POST[bln];
		
		$ambil=mysql_query("SELECT * FROM nasabah WHERE id_rekening='$Rekening'");
		$hasil=mysql_fetch_array($ambil);
	echo"<form method=post action=saldo_terendah.php>
	     <table width=700px border=1 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:#ccffff;'>
		 <tr style='background-color:#ccffaa;'><td style='text-align:left;'>TRANSAKSI SALDO TERENDAH</td><td style='text-align:right;'>Nasabah : $hasil[nama_nasabah]</td></tr>
		 <tr><td width='400px'>No. Rekening</td><td width='300px'><input type=text name=rekening value='$hasil[id_rekening]' readonly></td></tr>
		 <tr><td>Bulan</td><td><select name=bln>";
			for($i=1;$i<=12;$i++)
			{ 
				if($i<10){
				echo"<option value=0$i>0$i</option>";
				}else{
					echo"<option value=$i>$i</option>";
				}	
			}
		 echo"</select></td></tr>
		 <tr><td>Hitung Bunga</td><td><select name=bunga>";
			
				echo"<option value=saldoterendah>Saldo Terendah</option>
					 <option value=saldoratarata>Saldo Rata-Rata</option>
					 <option value=saldoharian>Saldo Harian</option>";
		 echo"</select></td></tr>
		 <tr><td>Bunga</td><td><select name=model>";
			
				echo"<option value=harian>Harian</option>
					 <option value=bulanan>Bulanan</option>";
				
		 echo"</select></td></tr>
		 <tr><td>Persen Bunga</td><td><select name=persen>";
			    for($k=1;$k<=24;$k++){
				echo"<option value=$k>$k</option>";
				}
		 echo"</select>%</td></tr>
		 <tr><td>Pajak</td><td><select name=pajak>";
			    for($k=1;$k<=15;$k++){
				echo"<option value=$k>$k</option>";
				}
		 echo"</select>%</td></tr>
		 
		 <tr><td colspan=2 style='text-align:center;'><input type=submit name=submit value=SUBMIT></td></tr>
		 </table></form>";
		$pilih1=mysql_query("SELECT tgl FROM rekening WHERE no_rekening='$Rekening' AND MID(tgl,6,2)='$Bln'"); 
		 $jumlah=mysql_num_rows($pilih1);
		 echo"$jumlah";
		 $data=mysql_fetch_array($pilih1);
		 echo"<table width=500px border=1 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:#ccffff;'>";
		 echo"<tr style='background-color:#ccffaa;'>";
		 if($Bln=="01"){
			 $Bln="Januari";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln </td><td colspan=3 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="02"){
			 $Bln="Februari";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="03"){
			 $Bln="Maret";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="04"){
			 $Bln="April";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="05"){
			 $Bln="Mei";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="06"){
			 $Bln="Juni";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="07"){
			 $Bln="Juli";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="08"){
			 $Bln="Agustus";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="09"){
			 $Bln="September";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="10"){
			 $Bln="Oktober";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="11"){
			 $Bln="November";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="12"){
			 $Bln="Desember";
		 echo"<td colspan=3>SALDO RATA-RATA : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }
		 echo"</tr></table>";
	}elseif(isset($_POST[submit]) AND $_POST[bunga]=='saldoharian'){
		$Rekening=$_POST[rekening];
		$Bln=$_POST[bln];
		
		$ambil=mysql_query("SELECT * FROM nasabah WHERE id_rekening='$Rekening'");
		$hasil=mysql_fetch_array($ambil);
	echo"<form method=post action=saldo_terendah.php>
	     <table width=700px border=1 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:#ccffff;'>
		 <tr style='background-color:#ccffaa;'><td style='text-align:left;'>TRANSAKSI SALDO HARIAN</td><td style='text-align:right;'>Nasabah : $hasil[nama_nasabah]</td></tr>
		 <tr><td width='400px'>No. Rekening</td><td width='300px'><input type=text name=rekening value='$hasil[id_rekening]' readonly></td></tr>
		 <tr><td>Bulan</td><td><select name=bln>";
			for($i=1;$i<=12;$i++)
			{ 
				if($i<10){
				echo"<option value=0$i>0$i</option>";
				}else{
					echo"<option value=$i>$i</option>";
				}	
			}
		 echo"</select></td></tr>
		 <tr><td>Hitung Bunga</td><td><select name=bunga>";
			
				echo"<option value=saldoterendah>Saldo Terendah</option>
					 <option value=saldoratarata>Saldo Rata-Rata</option>
					 <option value=saldoharian>Saldo Harian</option>";
		 echo"</select></td></tr>
		 <tr><td>Bunga</td><td><select name=model>";
			
				echo"<option value=harian>Harian</option>
					 <option value=bulanan>Bulanan</option>";
				
		 echo"</select></td></tr>
		 <tr><td>Persen Bunga</td><td><select name=persen>";
			    for($k=1;$k<=24;$k++){
				echo"<option value=$k>$k</option>";
				}
		 echo"</select>%</td></tr>
		 <tr><td>Pajak</td><td><select name=pajak>";
			    for($k=1;$k<=15;$k++){
				echo"<option value=$k>$k</option>";
				}
		 echo"</select>%</td></tr>
		 
		 <tr><td colspan=2 style='text-align:center;'><input type=submit name=submit value=SUBMIT></td></tr>
		 </table></form>";
		$pilih1=mysql_query("SELECT tgl FROM rekening WHERE no_rekening='$Rekening' AND MID(tgl,6,2)='$Bln'"); 
		 $jumlah=mysql_num_rows($pilih1);
		 $k=1;$i=1;
		 for ($i=1;$i<=$jumlah;$i++){
			  $data[$i]=mysql_fetch_array($pilih1);
		      $sel[$i]=$data[$i][tgl];
			  $k=(strtotime($sel[$i])/86400);
			  echo $k."<br>";
		 }
		 for($i=1;$i<$jumlah;$i++){
			 $k=(strtotime($sel[$i+1])/86400)-(strtotime($sel[$i])/86400);
			 echo $k."<br>";
		 }
		 echo"<table width=500px border=1 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:#ccffff;'>";
		 echo"<tr style='background-color:#ccffaa;'>";
		 if($Bln=="01"){
			 $Bln="Januari";
		 echo"<td colspan=3>SALDO HARIAN : $Bln </td><td colspan=3 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="02"){
			 $Bln="Februari";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="03"){
			 $Bln="Maret";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="04"){
			 $Bln="April";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="05"){
			 $Bln="Mei";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="06"){
			 $Bln="Juni";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="07"){
			 $Bln="Juli";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="08"){
			 $Bln="Agustus";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="09"){
			 $Bln="September";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="10"){
			 $Bln="Oktober";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="11"){
			 $Bln="November";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }elseif($Bln=="12"){
			 $Bln="Desember";
		 echo"<td colspan=3>SALDO HARIAN : $Bln</td><td colspan=4 style='text-align:right;' >$data[terendah]</td>";
		 }
		 echo"</tr></table>";
	}else{
		$Rekening = $_GET[rek];
		$ambil=mysql_query("SELECT * FROM nasabah WHERE id_rekening='$Rekening'");
		$hasil=mysql_fetch_array($ambil);
	echo"<form method=post action=saldo_terendah.php>
	     <table width='700px' border=1 style='border-collapse:collapse;
		  background-color:#ccffff;'>
		 <tr style='background-color:#ccffaa;'><td style='text-align:left;'>TRANSAKSI SALDO TERENDAH</td><td style='text-align:right;'>Nasabah : $hasil[nama_nasabah]</td></tr>
		 <tr><td width='400px'>No. Rekening</td><td width='300px'><input type=text name=rekening value='$hasil[id_rekening]' readonly></td></tr>
		 <tr><td >Bulan</td><td><select name=bln>";
			for($i=1;$i<=12;$i++)
			{ 
				if($i<10){
				echo"<option value=0$i>0$i</option>";
				}else{
					echo"<option value=$i>$i</option>";
				}	
			}
		 echo"</select></td></tr>
		 <tr><td>Hitung Bunga</td><td><select name=bunga>";
				echo"<option value=saldoterendah>Saldo Terendah</option>
					 <option value=saldoratarata>Saldo Rata-Rata</option>
					 <option value=saldoharian>Saldo Harian</option>";
		 echo"</select></td></tr>
		 <tr><td>Bunga</td><td><select name=model>";
			
				echo"<option value=harian>Harian</option>
					 <option value=bulanan>Bulanan</option>";
				
		 echo"</select></td></tr>
		 <tr><td>Persen Bunga</td><td><select name=persen>";
			    for($k=1;$k<=24;$k++){
				echo"<option value=$k>$k</option>";
				}
		 echo"</select>%</td></tr>
		 <tr><td>Pajak</td><td><select name=pajak>";
			    for($k=1;$k<=15;$k++){
				echo"<option value=$k>$k</option>";
				}
		 echo"</select>%</td></tr>
		 
		 <tr><td colspan=2 style='text-align:center;'><input type=submit name=submit value=SUBMIT></td></tr>
		 </table></form>";
	}
		 
?>
</div>
</body>
</html>