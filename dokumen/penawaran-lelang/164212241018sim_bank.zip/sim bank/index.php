<!DOCTYPE html>
<html>
<head>
<title>REKENING</title>
<meta charset="utf-8">
<link type="text/css" rel="stylesheet" href="css/kondisi.css">
</head>
<body>
<div class=kondisi>
<?php
		$Nama=$_POST[nama];
		$Rekening=$_POST[rekening];
		$kon=mysql_connect("localhost","root","Zaifulati123") or die("Koneksi Gagal");
		mysql_select_db("tabungan");
	echo"<form method=post action=nasabah.php>
	     <table width=400 border=0 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:silver;'>
		 <tr><td colspan=2 style='text-align:center;'>DATA NASABAH</td></tr>
		 <tr><td>No. Rekening</td><td><input type=text name=rekening size=15 value='$Rekening'></td></tr>
		 <tr><td>Nama Nasabah</td><td><input type=text name=nama size=40 value='$Nama'></td></tr>
		 <tr><td colspan=4 style='text-align:center;'><input type=submit name=submit value=SUBMIT></td></tr>
		 </table></form>";
	    if(isset($_POST[submit])){  
			$input=mysql_query("INSERT INTO nasabah values('$Rekening','$Nama')"); 
		}
		 $pilih=mysql_query("SELECT * FROM nasabah"); $no=1;
		 echo"<table width=400 border=1 cellpadding=3 cellspacing=3 style='border-collapse:collapse;
		  background-color:magenta;'>
		 <tr><td colspan=4 style='text-align:center;'>DATA NASABAH</td></tr>";
		 echo"<tr><td>No</td><td>No. Rekening</td><td>Nama Nasabah</td><td>Proses</td></tr>";
		 while($data=mysql_fetch_array($pilih))
		 {
		 echo"<tr><td>$no.</td><td>$data[id_rekening]</td><td>$data[nama_nasabah]</td>
		                <td><a href='rekening.php?rek=$data[id_rekening]' style='text-decoration:none;'>Transaksi</a>&nbsp;|&nbsp;
						    <a href='saldo_terendah.php?rek=$data[id_rekening]' style='text-decoration:none;'>Hitung Bunga</a></td></tr>";
		 $no++;
		 }
		 echo"</table>";
?>
</div>
</body>
</html>