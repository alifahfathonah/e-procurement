#Ajax CRUD Codeigniter with Bootstrap modals and Datatables#

###Demo###

Preview [ demo ]( http://edwardleon.com.ve/demo/crud )

###Requirements###

1. PHP 5+.
2. Apache Server 2
3. Mysql Server 5+

###Installation###

1. Download CRUD demo from github repository https://github.com/eleonsolar/crud-demo.git
2. Put it in http server
3. Restore backup database. It's in the folder "database".
4. Finished.
