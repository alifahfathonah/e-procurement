#CRUD hecho con Codeigniter, bootstrap modals y libreria datatable#

###Demo###

Ver [ demo ]( http://edwardleon.com.ve/demo/crud )

###Requerimientos###

1. PHP 5+.
2. Apache Server 2
3. Mysql Server 5+

###Instalación###

1. Descarga el demo desde el repositorio github https://github.com/eleonsolar/crud-demo.git
2. Colocalo en el servidor http
3. Restaura el backup de la base de datos. Eso está en la carpeta "database".
4. Terminado.
