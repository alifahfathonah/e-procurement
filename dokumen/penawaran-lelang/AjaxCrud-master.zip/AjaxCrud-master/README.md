# AjaxCrud
CRUD tanpa refresh dengan Codeigniter 3 + Ajax
 ![alt text](https://raw.githubusercontent.com/fariswidhi/AjaxCrud/master/1.png)
 ![alt text](https://raw.githubusercontent.com/fariswidhi/AjaxCrud/master/2.png)
 ![alt text](https://raw.githubusercontent.com/fariswidhi/AjaxCrud/master/3.png)
 ![alt text](https://raw.githubusercontent.com/fariswidhi/AjaxCrud/master/4.png)