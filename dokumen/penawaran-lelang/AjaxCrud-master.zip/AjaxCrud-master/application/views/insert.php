	
		<input type="text"  class="form-control name" style="margin: 5px;" placeholder="Nama">
		<input type="text"  class="form-control price"  style="margin: 5px;" placeholder="Harga">
		<center>
		<button class="btn btn-primary insert">Tambah</button>			
		</center>
