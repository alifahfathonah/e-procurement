	
		<input type="text" name="" value="<?php echo $data[0]->barang; ?>" class="form-control name" style="margin: 5px;">
		<input type="text" name="" class="form-control price" value="<?php echo $data[0]->harga; ?>" style="margin: 5px;">
		<center>
		<button data-id="<?php echo $data[0]->id_barang; ?>" class="btn btn-primary update">Ubah</button>			
		</center>
