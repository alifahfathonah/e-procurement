<?php
     echo $calendar;
?>

<div id="add_note_alert" class="alert alert-info  alert_modal hide">  
    <i class="icon-spinner icon-large icon-spin"></i> Adding Note..
</div>
