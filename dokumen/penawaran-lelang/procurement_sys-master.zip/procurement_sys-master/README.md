##PROCUREMENT SYS 
### Version
0.01

>Not sure whether there'll be another version though.

######Demo of the project is found at: http://procurementsys-gmanguru.rhcloud.com/
- For the user pages Username and Password is "demo"
- For the admin section Username and Password is: "admin".

######If the demo system takes more time to load in the browser than unexpected, give it a minute. Once the system loads it'll run smoothly as you continue testing it.
# 
# 


###Tech
The system was made using the codeigniter php framework.

### Installation


```sh
-Included in the "procurementSys" folder is an sql file. The sql is made for a mysql database.

-Import the sql file into phpmyadmin of your local or remote server. The database and the corresponding tables will be imported.

-Copy the "procurementSys" folder to the root of your webserver, from there you will be able to run it.

-If you are able to successfully reach the homepage then the username and password is:"admin".

-Once you open the admin account, click the "user management" link and view the user details of the other users of the system who are able to access the system with their own individual accounts. In order to access their accounts just use their username attribute as both the username and password.
```









